منصة الاجتماعيات — الأستاذ أحمد بوعمود

هذا موقع كامل جاهز لإعادة النشر.

طريقة الرفع:
1) فك الضغط.
2) ارفع محتوى مجلد ahmed_bouamoud_full_website إلى الاستضافة.
3) افتح index.html.

الصفحات:
- index.html الصفحة الرئيسية
- pages/library.html المكتبة
- pages/1bac.html الأولى باك
- pages/3ac.html الثالثة إعدادي
- pages/exams.html الامتحانات والتمارين
- pages/methodology.html المنهجيات
- admin/index.html صفحة مساعدة لتوليد كود مورد جديد

طريقة التحيين:
- افتح assets/data/resources.json
- أضف مورداً جديداً أو عدّل مورد موجود
- ضع الصور في assets/img
- لكل مورد صفحة تلقائية الشكل داخل resources

التوقيع المعتمد: الأستاذ احمد بوعمود
