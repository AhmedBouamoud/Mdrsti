نسخة لوحة الإضافة الأوتوماتيكية

ما الجديد؟
- تم تجهيز /admin بلوحة Decap CMS.
- يتم تعديل assets/data/resources.json مباشرة من لوحة الإدارة.
- ترفع الصور تلقائياً إلى assets/img.
- يمكن إضافة درس/إنفوغرافيا/تمرين/امتحان من الهاتف.

بعد رفع الملفات إلى GitHub:
1) في Netlify ادخل إلى ahmedbouamoud.com.
2) Project configuration > Identity > Enable Identity.
3) Services > Git Gateway > Enable Git Gateway.
4) Invite users وأرسل الدعوة إلى بريدك.
5) افتح https://ahmedbouamoud.com/admin
6) أضف مورداً جديداً ثم Publish.

ملاحظة:
إذا أضفت مورداً جديداً، اجعل رابط المورد:
resources/resource.html?id=ضع-نفس-المعرف
مثال:
المعرّف: bac-water-001
الرابط: resources/resource.html?id=bac-water-001
